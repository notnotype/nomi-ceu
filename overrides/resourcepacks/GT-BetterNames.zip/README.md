# GregTech Better Names

A small resource pack to give machines a cooler name.

## License

[CC BY-NC-SA 4.0](http://creativecommons.org/licenses/by-nc-sa/4.0/deed.en)

[Screenshot of the license](https://i.imgur.com/3QeuL49.png)

